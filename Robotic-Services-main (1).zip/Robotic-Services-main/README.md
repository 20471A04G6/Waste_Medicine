# Robotic-services
This is a Informational bot application developoed for education related to give information about Robotic-Services.

## This web based informational bot application has been developed for the accomplishment of future ready talent internship program launched by microsoft, future skil prime, Quess, GitHub,
# Project title:
   Azure Chat Bot
# Project description 😃 :
I have created a informational bot named "Azure Chat bot" using Html and services like QnA maker,Web app bot.It helps the user to finds information about robotics mainly used in the healthcare sectors; What are robotic  and it's history and about services. In this website I make six pages i.e; Home, About, Contact, F.A.Q, ChatBot,learn more. It's look likes a professional bot. I am trying to solve the real world problem like in these days we are sufuring with so many health problems for this we are moving to the robotic services for good  production.for information here and there. So I make a bot where I try to give every details of robotics . My project helps both learners and explorers like for learners I provided every details i.e; history, developer (s), services etc.. and for explorers I gave website links and everything there in the bot to know more to create , build, deploy etc ...

# Features and functionalities 🧐:
 - Interactive and responsive UI,
 - Has many features and visual innovative effects.
 - Have an aesthetically pleasing visual design and architecture.
 - Has collection of pages including Home, About, Contact, ChatBot, F.A.Q ,learn more education  realted information.
- User can know about information about the robotics through this bot.
 - Included the contact information to increase scope of improvement.

# About ChatBot 💬:
- Created a chat bot About Robotics.
- Also available with app.
- "Azure ChatBot" looks like a professional bot where you can find all information about the surgaries maid by the robots .
- Bot contains information about Azure like i.e; history, of Azure and services etc..
- we provided Gallery in home page to find more and also official website with links with innovative ideas ; go through it.
- Azure ChatBot useful for both learners and explorers.
- Main concept that my bot gives;About Azure,how it works, history, full forms and detailed view of Azure.
# Screenshorts:

# Home Page

![Screenshot (1)](https://user-images.githubusercontent.com/114461199/192855686-60083000-85e6-4403-b0b8-b514b4dbfe50.png)

# Gallary

![s2](https://user-images.githubusercontent.com/114461199/192852330-356df3db-d237-4800-9dfc-da96973ce6e0.png)
![a1](https://user-images.githubusercontent.com/114461199/192856158-23280c78-57e3-4b69-a94e-ffbd6f723fb8.png)

# chart Bot

![s1](https://user-images.githubusercontent.com/114461199/192850881-729141d4-c6e6-4fe9-b900-26765429d63d.png)

# Contact us

![s2](https://user-images.githubusercontent.com/114461199/192852468-dee23d54-4137-4e32-af82-c00cf7a8febc.png)

# About us:

![s3](https://user-images.githubusercontent.com/114461199/192852985-452aecd4-3432-43f4-8da9-f3bbe58b9d92.png)

# Learn more:

![s4](https://user-images.githubusercontent.com/114461199/192853140-0a674493-2614-4b79-bd08-c24dd1c73a07.png)
![s0](https://user-images.githubusercontent.com/114461199/192853912-587ccaa2-1780-4c50-97be-46ca57145544.png)

# FAQ page

![s9](https://user-images.githubusercontent.com/114461199/192855136-802c463e-d591-43d6-8dd8-44d9ef3fd963.png)





# Tech Stack


## Languages and Azure services used in my bot:
- HTML
- QnA maker
- WebApp Bot
- JavaScript












